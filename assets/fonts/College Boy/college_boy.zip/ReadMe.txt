
These are the rules!

This font is free, but...

This is a recreation of a font I couldn't find in digital format. Don't put it on a CD or website or resell it in anyway without first contacting me (fontboy@subflux.com). If you want a friend to have it, send them a link to it (www.subflux.com/fonts.htm).

If you designed this font originally and are upset that I have the temerity to give away my version, send me an email, we can work it out (www.subflux.com/fonts.htm).

If you use this font, send me a link or JPG of the font in action, I love to see my babies at work. (fontboy@subflux.com)

Oh, and this font is offered as is, it may missing letters or stuff and if it blows up your machine don't blame me it isn't my fault.

Thanks for fonting,
MickeyRossi